<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>labour booking portal</title>
    <link rel="stylesheet" href="home.css">
</head>
<body>
  <nav>
    <div class="sappy">
      <h1>labour booking</h1>
      <div class="hi">
      <a href="login.php" class="hello">login</a>
      <a href="register.php" class="hello">register</a>
      <a href="" class="hello">feedback</a>
      </div>
    </div>
  </nav>
    <div class="fatma"></div>
        <div class="para" >   
        <h1 class="jo">Labour Booking Website</h1>
        <p>A labor booking website serves as a digital platform designed to streamline the process of hiring temporary or
             freelance workers across various industries. It enables businesses to efficiently post job opportunities, s-
             pecify their requirements,and connect with a pool of skilled professionals. Users can browse through profil-
             es, review qualifications, and book labor services with just a few clicks. For workers,   the website offers 
             a convenient way to find and apply for job assignments,manage their schedules, and track payments. By lever-
             aging technology, these platforms enhance the efficiency of labor management,reduce administrative overhead,
             and ensure that both employers and workers can find suitable matches quickly and effectively.</p>
        </div>   
</body>
</html>